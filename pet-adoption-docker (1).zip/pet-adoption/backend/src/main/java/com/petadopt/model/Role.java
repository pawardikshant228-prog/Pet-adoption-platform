package com.petadopt.model;

public enum Role { ADOPTER, ADMIN }
