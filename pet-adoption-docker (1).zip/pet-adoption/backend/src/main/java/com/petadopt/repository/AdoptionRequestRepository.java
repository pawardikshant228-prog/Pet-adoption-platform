package com.petadopt.repository;

import com.petadopt.model.AdoptionRequest;
import com.petadopt.model.RequestStatus;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AdoptionRequestRepository extends JpaRepository<AdoptionRequest, Long> {
    @EntityGraph(attributePaths = {"user", "pet"})
    List<AdoptionRequest> findAllByOrderByRequestDateDesc();

    @EntityGraph(attributePaths = {"user", "pet"})
    List<AdoptionRequest> findByUserIdOrderByRequestDateDesc(Long userId);

    boolean existsByUserIdAndPetIdAndStatus(Long userId, Long petId, RequestStatus status);
    long countByStatus(RequestStatus status);
}
