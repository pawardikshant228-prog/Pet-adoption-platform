package com.petadopt.controller;

import com.petadopt.model.Pet;
import com.petadopt.service.PetService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/** GET /pets is public; create/update/delete are ADMIN-only (see SecurityConfig). */
@RestController
@RequestMapping("/pets")
public class PetController {
    private final PetService service;
    public PetController(PetService service) { this.service = service; }

    @GetMapping
    public List<Pet> list(@RequestParam(required = false) String q,
                          @RequestParam(required = false) String species,
                          @RequestParam(required = false) String breed,
                          @RequestParam(required = false) String location,
                          @RequestParam(required = false) Integer minAge,
                          @RequestParam(required = false) Integer maxAge,
                          @RequestParam(required = false) Boolean available) {
        return service.search(q, species, breed, location, minAge, maxAge, available);
    }

    @GetMapping("/{id}")
    public Pet get(@PathVariable Long id) { return service.get(id); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Pet create(@Valid @RequestBody Pet pet) { return service.create(pet); }

    @PutMapping("/{id}")
    public Pet update(@PathVariable Long id, @Valid @RequestBody Pet pet) { return service.update(id, pet); }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { service.delete(id); }
}
