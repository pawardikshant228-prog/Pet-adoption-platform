package com.petadopt.repository;

import com.petadopt.model.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface PetRepository extends JpaRepository<Pet, Long> {

    @Query("""
        SELECT p FROM Pet p
        WHERE (:q IS NULL OR LOWER(p.name) LIKE LOWER(CONCAT('%', :q, '%'))
                          OR LOWER(p.breed) LIKE LOWER(CONCAT('%', :q, '%')))
          AND (:species IS NULL OR LOWER(p.species) = LOWER(:species))
          AND (:breed IS NULL OR LOWER(p.breed) LIKE LOWER(CONCAT('%', :breed, '%')))
          AND (:location IS NULL OR LOWER(p.location) LIKE LOWER(CONCAT('%', :location, '%')))
          AND (:minAge IS NULL OR p.ageYears >= :minAge)
          AND (:maxAge IS NULL OR p.ageYears <= :maxAge)
          AND (:available IS NULL OR p.available = :available)
        ORDER BY p.id DESC
        """)
    List<Pet> search(@Param("q") String q,
                     @Param("species") String species,
                     @Param("breed") String breed,
                     @Param("location") String location,
                     @Param("minAge") Integer minAge,
                     @Param("maxAge") Integer maxAge,
                     @Param("available") Boolean available);
}
