package com.petadopt.controller;

import com.petadopt.dto.Dtos.*;
import com.petadopt.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final AuthService auth;
    public AuthController(AuthService auth) { this.auth = auth; }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthResponse register(@Valid @RequestBody RegisterRequest in) { return auth.register(in); }

    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest in) { return auth.login(in); }
}
