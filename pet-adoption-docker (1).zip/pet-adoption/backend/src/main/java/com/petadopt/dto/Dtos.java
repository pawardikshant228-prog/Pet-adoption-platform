package com.petadopt.dto;

import com.petadopt.model.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

public final class Dtos {
    private Dtos() {}

    public record RegisterRequest(
            @NotBlank @Size(max = 100) String fullName,
            @NotBlank @Email @Size(max = 150) String email,
            @Size(max = 20) String phone,
            @NotBlank @Size(min = 6, max = 72, message = "Password must be 6-72 characters") String password) {}

    public record LoginRequest(@NotBlank @Email String email, @NotBlank String password) {}

    public record UserResponse(Long id, String fullName, String email, String phone, Role role) {
        public static UserResponse from(User u) {
            return new UserResponse(u.getId(), u.getFullName(), u.getEmail(), u.getPhone(), u.getRole());
        }
    }

    public record AuthResponse(String token, UserResponse user) {}

    public record AdoptionRequestCreate(
            @NotNull Long petId,
            @NotBlank @Size(min = 10, max = 1000, message = "Tell us a little more (10-1000 characters)") String message) {}

    public record StatusUpdate(@NotNull RequestStatus status, @Size(max = 1000) String reviewNotes) {}

    public record AdoptionRequestResponse(Long id, Long petId, String petName, String petImageUrl,
                                          Long userId, String userName, String userEmail,
                                          LocalDateTime requestDate, RequestStatus status,
                                          String message, String reviewNotes) {
        public static AdoptionRequestResponse from(AdoptionRequest r) {
            return new AdoptionRequestResponse(r.getId(), r.getPet().getId(), r.getPet().getName(),
                    r.getPet().getImageUrl(), r.getUser().getId(), r.getUser().getFullName(),
                    r.getUser().getEmail(), r.getRequestDate(), r.getStatus(), r.getMessage(), r.getReviewNotes());
        }
    }

    public record Stats(long totalPets, long availablePets, long pending, long approved, long rejected) {}
}
