package com.petadopt.controller;

import com.petadopt.dto.Dtos.*;
import com.petadopt.service.AdoptionRequestService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class AdoptionRequestController {
    private final AdoptionRequestService service;
    public AdoptionRequestController(AdoptionRequestService service) { this.service = service; }

    // Adopter: submit + view own requests
    @PostMapping("/adoption-requests")
    @ResponseStatus(HttpStatus.CREATED)
    public AdoptionRequestResponse submit(Authentication auth, @Valid @RequestBody AdoptionRequestCreate in) {
        return service.submit(auth.getName(), in);
    }

    @GetMapping("/adoption-requests/mine")
    public List<AdoptionRequestResponse> mine(Authentication auth) { return service.mine(auth.getName()); }

    // Admin: review pipeline
    @GetMapping("/admin/adoption-requests")
    public List<AdoptionRequestResponse> all() { return service.all(); }

    @PatchMapping("/admin/adoption-requests/{id}")
    public AdoptionRequestResponse review(@PathVariable Long id, @Valid @RequestBody StatusUpdate in) {
        return service.review(id, in);
    }

    @GetMapping("/admin/stats")
    public Stats stats() { return service.stats(); }
}
