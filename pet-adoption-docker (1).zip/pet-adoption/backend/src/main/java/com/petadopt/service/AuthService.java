package com.petadopt.service;

import com.petadopt.dto.Dtos.*;
import com.petadopt.exception.ApiException;
import com.petadopt.model.*;
import com.petadopt.repository.UserRepository;
import com.petadopt.security.JwtService;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    public AuthService(UserRepository users, PasswordEncoder encoder, JwtService jwt) {
        this.users = users; this.encoder = encoder; this.jwt = jwt;
    }

    public AuthResponse register(RegisterRequest in) {
        if (users.existsByEmailIgnoreCase(in.email()))
            throw ApiException.conflict("An account with this email already exists.");
        User u = new User();
        u.setFullName(in.fullName().trim());
        u.setEmail(in.email().trim().toLowerCase());
        u.setPhone(in.phone());
        u.setPassword(encoder.encode(in.password()));
        u.setRole(Role.ADOPTER);
        users.save(u);
        return new AuthResponse(jwt.generate(u), UserResponse.from(u));
    }

    public AuthResponse login(LoginRequest in) {
        User u = users.findByEmailIgnoreCase(in.email())
                .filter(x -> encoder.matches(in.password(), x.getPassword()))
                .orElseThrow(() -> new BadCredentialsException("bad credentials"));
        return new AuthResponse(jwt.generate(u), UserResponse.from(u));
    }
}
