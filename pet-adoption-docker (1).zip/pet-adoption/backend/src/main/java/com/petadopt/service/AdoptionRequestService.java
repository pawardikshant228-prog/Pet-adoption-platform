package com.petadopt.service;

import com.petadopt.dto.Dtos.*;
import com.petadopt.exception.ApiException;
import com.petadopt.model.*;
import com.petadopt.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class AdoptionRequestService {
    private final AdoptionRequestRepository requests;
    private final PetRepository pets;
    private final UserRepository users;

    public AdoptionRequestService(AdoptionRequestRepository r, PetRepository p, UserRepository u) {
        this.requests = r; this.pets = p; this.users = u;
    }

    @Transactional
    public AdoptionRequestResponse submit(String email, AdoptionRequestCreate in) {
        User user = users.findByEmailIgnoreCase(email).orElseThrow(() -> ApiException.notFound("User not found"));
        Pet pet = pets.findById(in.petId()).orElseThrow(() -> ApiException.notFound("Pet not found"));
        if (!pet.isAvailable()) throw ApiException.conflict("This pet is no longer available for adoption.");
        if (requests.existsByUserIdAndPetIdAndStatus(user.getId(), pet.getId(), RequestStatus.PENDING))
            throw ApiException.conflict("You already have a pending request for this pet.");

        AdoptionRequest r = new AdoptionRequest();
        r.setUser(user);
        r.setPet(pet);
        r.setMessage(in.message().trim());
        return AdoptionRequestResponse.from(requests.save(r));
    }

    @Transactional(readOnly = true)
    public List<AdoptionRequestResponse> mine(String email) {
        User user = users.findByEmailIgnoreCase(email).orElseThrow(() -> ApiException.notFound("User not found"));
        return requests.findByUserIdOrderByRequestDateDesc(user.getId()).stream()
                .map(AdoptionRequestResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public List<AdoptionRequestResponse> all() {
        return requests.findAllByOrderByRequestDateDesc().stream().map(AdoptionRequestResponse::from).toList();
    }

    /** Admin review. Approving marks the pet unavailable. */
    @Transactional
    public AdoptionRequestResponse review(Long id, StatusUpdate in) {
        AdoptionRequest r = requests.findById(id).orElseThrow(() -> ApiException.notFound("Request not found"));
        if (in.status() == RequestStatus.PENDING) throw ApiException.badRequest("Choose APPROVED or REJECTED.");
        if (r.getStatus() != RequestStatus.PENDING)
            throw ApiException.conflict("This request has already been " + r.getStatus().name().toLowerCase() + ".");
        if (in.status() == RequestStatus.APPROVED && !r.getPet().isAvailable())
            throw ApiException.conflict("This pet has already been adopted.");
        r.setStatus(in.status());
        r.setReviewNotes(in.reviewNotes());
        if (in.status() == RequestStatus.APPROVED) r.getPet().setAvailable(false);
        return AdoptionRequestResponse.from(r);
    }

    @Transactional(readOnly = true)
    public Stats stats() {
        return new Stats(pets.count(), pets.search(null, null, null, null, null, null, true).size(),
                requests.countByStatus(RequestStatus.PENDING),
                requests.countByStatus(RequestStatus.APPROVED),
                requests.countByStatus(RequestStatus.REJECTED));
    }
}
