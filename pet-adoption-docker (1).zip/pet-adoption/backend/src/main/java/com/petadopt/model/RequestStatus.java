package com.petadopt.model;

public enum RequestStatus { PENDING, APPROVED, REJECTED }
