package com.petadopt.service;

import com.petadopt.exception.ApiException;
import com.petadopt.model.Pet;
import com.petadopt.repository.PetRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class PetService {
    private final PetRepository pets;
    public PetService(PetRepository pets) { this.pets = pets; }

    private static String clean(String s) { return (s == null || s.isBlank()) ? null : s.trim(); }

    @Transactional(readOnly = true)
    public List<Pet> search(String q, String species, String breed, String location,
                            Integer minAge, Integer maxAge, Boolean available) {
        return pets.search(clean(q), clean(species), clean(breed), clean(location), minAge, maxAge, available);
    }

    @Transactional(readOnly = true)
    public Pet get(Long id) {
        return pets.findById(id).orElseThrow(() -> ApiException.notFound("Pet " + id + " not found"));
    }

    @Transactional
    public Pet create(Pet p) { p.setId(null); return pets.save(p); }

    @Transactional
    public Pet update(Long id, Pet in) {
        Pet p = get(id);
        p.setName(in.getName());
        p.setSpecies(in.getSpecies());
        p.setBreed(in.getBreed());
        p.setAgeYears(in.getAgeYears());
        p.setGender(in.getGender());
        p.setLocation(in.getLocation());
        p.setHealthNotes(in.getHealthNotes());
        p.setDescription(in.getDescription());
        p.setImageUrl(in.getImageUrl());
        p.setAvailable(in.isAvailable());
        return p;
    }

    @Transactional
    public void delete(Long id) {
        Pet p = get(id);
        try {
            pets.delete(p);
            pets.flush();
        } catch (org.springframework.dao.DataIntegrityViolationException e) {
            throw ApiException.conflict("This pet has adoption requests and cannot be deleted. Mark it unavailable instead.");
        }
    }
}
