package com.petadopt.config;

import com.petadopt.model.*;
import com.petadopt.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataSeeder {

    @Bean
    CommandLineRunner seed(UserRepository users, PetRepository pets, PasswordEncoder enc,
                           @Value("${app.seed.enabled:true}") boolean enabled,
                           @Value("${app.seed.admin-email}") String adminEmail,
                           @Value("${app.seed.admin-password}") String adminPassword) {
        return args -> {
            if (!enabled) return;
            if (!users.existsByEmailIgnoreCase(adminEmail)) {
                User a = new User();
                a.setFullName("Shelter Admin");
                a.setEmail(adminEmail);
                a.setPassword(enc.encode(adminPassword));
                a.setRole(Role.ADMIN);
                users.save(a);
            }
            if (pets.count() == 0) {
                pets.save(pet("Bruno", "Dog", "Labrador Retriever", 3, "Male", "Pune",
                        "Vaccinated, neutered", "Gentle and playful. Loves fetch and great with kids.",
                        "https://images.unsplash.com/photo-1552053831-71594a27632d?w=800"));
                pets.save(pet("Luna", "Cat", "Siamese", 2, "Female", "Mumbai",
                        "Vaccinated, spayed", "Curious and talkative. Happiest in a sunny window.",
                        "https://images.unsplash.com/photo-1513245543132-31f507417b26?w=800"));
                pets.save(pet("Max", "Dog", "Indian Pariah", 1, "Male", "Delhi",
                        "Vaccinated, dewormed", "Energetic, smart and quick to learn tricks.",
                        "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=800"));
                pets.save(pet("Mittens", "Cat", "Persian", 5, "Female", "Bengaluru",
                        "Vaccinated, needs regular grooming", "Calm lap cat who prefers a quiet home.",
                        "https://images.unsplash.com/photo-1574158622682-e40e69881006?w=800"));
                pets.save(pet("Coco", "Rabbit", "Holland Lop", 1, "Female", "Pune",
                        "Healthy, vet-checked", "Soft, shy at first, and loves leafy greens.",
                        "https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?w=800"));
                pets.save(pet("Rocky", "Dog", "German Shepherd", 6, "Male", "Hyderabad",
                        "Vaccinated, mild arthritis (managed)", "Loyal senior companion looking for a calm family.",
                        "https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?w=800"));
            }
        };
    }

    private static Pet pet(String name, String species, String breed, int age, String gender,
                           String location, String health, String desc, String img) {
        Pet p = new Pet();
        p.setName(name); p.setSpecies(species); p.setBreed(breed); p.setAgeYears(age);
        p.setGender(gender); p.setLocation(location); p.setHealthNotes(health);
        p.setDescription(desc); p.setImageUrl(img); p.setAvailable(true);
        return p;
    }
}
