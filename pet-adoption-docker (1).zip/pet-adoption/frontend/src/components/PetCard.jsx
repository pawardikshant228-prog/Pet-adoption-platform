import { Link } from 'react-router-dom';

export const FALLBACK = 'data:image/svg+xml;utf8,' + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300"><rect width="100%" height="100%" fill="#f3e6d8"/><text x="50%" y="52%" font-size="72" text-anchor="middle">🐾</text></svg>'
);

export const ageLabel = (y) => (y === 0 ? 'Under 1 yr' : y === 1 ? '1 yr' : `${y} yrs`);

export default function PetCard({ pet }) {
  return (
    <Link to={`/pets/${pet.id}`} className="card pet-card">
      <div className="pet-img">
        <img src={pet.imageUrl || FALLBACK} alt={pet.name} loading="lazy"
             onError={(e) => { e.currentTarget.src = FALLBACK; }} />
        <span className={pet.available ? 'badge ok' : 'badge off'}>{pet.available ? 'Available' : 'Adopted'}</span>
      </div>
      <div className="pet-body">
        <h3>{pet.name}</h3>
        <p className="muted">{pet.breed || pet.species} · {ageLabel(pet.ageYears)}</p>
        <p className="muted small">📍 {pet.location}</p>
      </div>
    </Link>
  );
}
