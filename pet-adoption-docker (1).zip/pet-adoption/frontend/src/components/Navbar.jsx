import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Navbar() {
  const { user, isAdmin, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  const close = () => setOpen(false);

  return (
    <header className="navbar">
      <div className="container nav-inner">
        <Link to="/" className="brand" onClick={close}>🐾 PawHome</Link>
        <button className="burger" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)}>☰</button>
        <nav className={open ? 'links open' : 'links'} onClick={close}>
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/pets">Browse Pets</NavLink>
          {user && !isAdmin && <NavLink to="/my-requests">My Requests</NavLink>}
          {isAdmin && <NavLink to="/admin">Admin</NavLink>}
          {user ? (
            <>
              <span className="hello">Hi, {user.fullName.split(' ')[0]}</span>
              <button className="btn btn-ghost" onClick={() => { logout(); nav('/'); }}>Log out</button>
            </>
          ) : (
            <>
              <NavLink to="/login">Log in</NavLink>
              <Link to="/register" className="btn btn-primary">Sign up</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
