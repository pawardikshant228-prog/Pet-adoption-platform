export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <strong>🐾 PawHome</strong> — connecting pets with the people who will love them.
      </div>
    </footer>
  );
}
