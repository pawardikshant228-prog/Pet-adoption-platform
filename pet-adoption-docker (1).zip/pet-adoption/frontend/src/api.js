const BASE = import.meta.env.VITE_API_URL || 'http://localhost:8080';

export class ApiError extends Error {
  constructor(message, status, fields) {
    super(message);
    this.status = status;
    this.fields = fields || {};
  }
}

async function request(path, { method = 'GET', body, params } = {}) {
  const url = new URL(BASE + path);
  if (params) {
    Object.entries(params).forEach(([k, v]) => {
      if (v !== '' && v !== null && v !== undefined) url.searchParams.set(k, v);
    });
  }
  const headers = {};
  if (body) headers['Content-Type'] = 'application/json';
  const token = localStorage.getItem('token');
  if (token) headers.Authorization = `Bearer ${token}`;

  let res;
  try {
    res = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch {
    throw new ApiError('Cannot reach the server. Is the backend running?', 0);
  }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    if (res.status === 401 && token) window.dispatchEvent(new Event('auth-expired'));
    throw new ApiError(data?.message || `Request failed (${res.status})`, res.status, data?.errors);
  }
  return data;
}

export const api = {
  register: (b) => request('/auth/register', { method: 'POST', body: b }),
  login: (b) => request('/auth/login', { method: 'POST', body: b }),

  pets: (params) => request('/pets', { params }),
  pet: (id) => request(`/pets/${id}`),
  createPet: (b) => request('/pets', { method: 'POST', body: b }),
  updatePet: (id, b) => request(`/pets/${id}`, { method: 'PUT', body: b }),
  deletePet: (id) => request(`/pets/${id}`, { method: 'DELETE' }),

  submitRequest: (b) => request('/adoption-requests', { method: 'POST', body: b }),
  myRequests: () => request('/adoption-requests/mine'),

  adminRequests: () => request('/admin/adoption-requests'),
  reviewRequest: (id, b) => request(`/admin/adoption-requests/${id}`, { method: 'PATCH', body: b }),
  stats: () => request('/admin/stats'),
};
