import { useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';
import StatusBadge from '../components/StatusBadge.jsx';

const EMPTY = { name: '', species: 'Dog', breed: '', ageYears: 0, gender: 'Male', location: '', healthNotes: '', description: '', imageUrl: '', available: true };

export default function Admin() {
  const [tab, setTab] = useState('requests');
  const [stats, setStats] = useState(null);
  const [requests, setRequests] = useState([]);
  const [pets, setPets] = useState([]);
  const [error, setError] = useState('');
  const [notes, setNotes] = useState({});
  const [form, setForm] = useState(null); // pet being edited/created

  const load = useCallback(async () => {
    try {
      const [s, r, p] = await Promise.all([api.stats(), api.adminRequests(), api.pets({})]);
      setStats(s); setRequests(r); setPets(p); setError('');
    } catch (e) { setError(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const review = async (id, status) => {
    try { await api.reviewRequest(id, { status, reviewNotes: notes[id] || '' }); await load(); }
    catch (e) { setError(e.message); load(); }
  };

  const savePet = async (e) => {
    e.preventDefault();
    try {
      const body = { ...form, ageYears: Number(form.ageYears) };
      if (form.id) await api.updatePet(form.id, body); else await api.createPet(body);
      setForm(null); await load();
    } catch (err) { setError(err.fields ? Object.values(err.fields).join(', ') : err.message); }
  };

  const removePet = async (p) => {
    if (!window.confirm(`Delete ${p.name}?`)) return;
    try { await api.deletePet(p.id); await load(); } catch (e) { setError(e.message); }
  };

  const f = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  return (
    <div className="container section">
      <h1>Admin dashboard</h1>
      {error && <div className="alert error">{error}</div>}

      {stats && (
        <div className="grid stats">
          {[['Total pets', stats.totalPets], ['Available', stats.availablePets], ['Pending', stats.pending],
            ['Approved', stats.approved], ['Rejected', stats.rejected]].map(([l, v]) => (
            <div className="card stat" key={l}><span className="stat-n">{v}</span><span className="muted small">{l}</span></div>
          ))}
        </div>
      )}

      <div className="tabs">
        <button className={tab === 'requests' ? 'active' : ''} onClick={() => setTab('requests')}>Adoption requests</button>
        <button className={tab === 'pets' ? 'active' : ''} onClick={() => setTab('pets')}>Manage pets</button>
      </div>

      {tab === 'requests' && (
        requests.length === 0 ? <div className="empty"><h3>No requests yet</h3></div> :
        <div className="list">
          {requests.map((r) => (
            <div className="card req" key={r.id}>
              <div className="row between wrap">
                <div><strong>{r.petName}</strong> <span className="muted">← {r.userName} ({r.userEmail})</span></div>
                <StatusBadge status={r.status} />
              </div>
              <p className="muted small">{new Date(r.requestDate).toLocaleString()}</p>
              <p>“{r.message}”</p>
              {r.status === 'PENDING' ? (
                <div className="row wrap">
                  <input className="grow" placeholder="Review notes (optional)" value={notes[r.id] || ''} onChange={(e) => setNotes({ ...notes, [r.id]: e.target.value })} />
                  <button className="btn btn-primary" onClick={() => review(r.id, 'APPROVED')}>Approve</button>
                  <button className="btn btn-danger" onClick={() => review(r.id, 'REJECTED')}>Reject</button>
                </div>
              ) : r.reviewNotes && <p className="small"><strong>Notes:</strong> {r.reviewNotes}</p>}
            </div>
          ))}
        </div>
      )}

      {tab === 'pets' && (
        <>
          <button className="btn btn-primary" onClick={() => setForm({ ...EMPTY })}>+ Add pet</button>
          {form && (
            <form className="card form pet-form" onSubmit={savePet}>
              <h3>{form.id ? 'Edit pet' : 'New pet'}</h3>
              <div className="two">
                <div><label>Name</label><input required value={form.name} onChange={f('name')} /></div>
                <div><label>Species</label>
                  <select value={form.species} onChange={f('species')}>{['Dog', 'Cat', 'Rabbit', 'Bird', 'Other'].map((s) => <option key={s}>{s}</option>)}</select></div>
                <div><label>Breed</label><input value={form.breed || ''} onChange={f('breed')} /></div>
                <div><label>Age (years)</label><input type="number" min="0" max="40" value={form.ageYears} onChange={f('ageYears')} /></div>
                <div><label>Gender</label>
                  <select value={form.gender || ''} onChange={f('gender')}><option>Male</option><option>Female</option></select></div>
                <div><label>Location</label><input required value={form.location} onChange={f('location')} /></div>
              </div>
              <label>Health notes</label><input value={form.healthNotes || ''} onChange={f('healthNotes')} />
              <label>Description</label><textarea rows="3" value={form.description || ''} onChange={f('description')} />
              <label>Image URL</label><input value={form.imageUrl || ''} onChange={f('imageUrl')} />
              <label className="check"><input type="checkbox" checked={form.available} onChange={f('available')} /> Available for adoption</label>
              <div className="row"><button className="btn btn-primary">Save</button><button type="button" className="btn btn-ghost" onClick={() => setForm(null)}>Cancel</button></div>
            </form>
          )}
          <div className="table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Species</th><th>Location</th><th>Status</th><th></th></tr></thead>
              <tbody>
                {pets.map((p) => (
                  <tr key={p.id}>
                    <td>{p.name}</td><td>{p.species}{p.breed ? ` · ${p.breed}` : ''}</td><td>{p.location}</td>
                    <td><span className={p.available ? 'badge ok' : 'badge off'}>{p.available ? 'Available' : 'Adopted'}</span></td>
                    <td className="actions">
                      <button className="btn btn-ghost" onClick={() => setForm({ ...p })}>Edit</button>
                      <button className="btn btn-ghost danger-text" onClick={() => removePet(p)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
