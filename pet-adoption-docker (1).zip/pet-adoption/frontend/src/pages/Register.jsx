import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Register() {
  const { register } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ fullName: '', email: '', phone: '', password: '' });
  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const on = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const validate = () => {
    const x = {};
    if (!f.fullName.trim()) x.fullName = 'Name is required';
    if (!/^\S+@\S+\.\S+$/.test(f.email)) x.email = 'Enter a valid email';
    if (f.phone && !/^[0-9+\-\s]{7,20}$/.test(f.phone)) x.phone = 'Enter a valid phone number';
    if (f.password.length < 6) x.password = 'Password must be at least 6 characters';
    return x;
  };

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    const v = validate();
    setErrors(v);
    if (Object.keys(v).length) return;
    setBusy(true);
    try {
      await register(f);
      nav('/pets', { replace: true });
    } catch (err) {
      setErrors(err.fields || {});
      setError(err.message);
    } finally { setBusy(false); }
  };

  const field = (k, label, type = 'text', ac) => (
    <>
      <label htmlFor={k}>{label}</label>
      <input id={k} type={type} autoComplete={ac} value={f[k]} onChange={on(k)} aria-invalid={!!errors[k]} />
      {errors[k] && <p className="field-error">{errors[k]}</p>}
    </>
  );

  return (
    <div className="container auth">
      <form className="card form" onSubmit={submit} noValidate>
        <h1>Create your account</h1>
        {error && <div className="alert error">{error}</div>}
        {field('fullName', 'Full name', 'text', 'name')}
        {field('email', 'Email', 'email', 'email')}
        {field('phone', 'Phone (optional)', 'tel', 'tel')}
        {field('password', 'Password', 'password', 'new-password')}
        <button className="btn btn-primary btn-block" disabled={busy}>{busy ? 'Creating…' : 'Sign up'}</button>
        <p className="muted small">Already registered? <Link to="/login">Log in</Link></p>
      </form>
    </div>
  );
}
