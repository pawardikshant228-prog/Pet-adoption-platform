import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api.js';
import PetCard from '../components/PetCard.jsx';

const SPECIES = ['Dog', 'Cat', 'Rabbit', 'Bird', 'Other'];

export default function Pets() {
  const [sp, setSp] = useSearchParams();
  const [pets, setPets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const f = {
    q: sp.get('q') || '', species: sp.get('species') || '', breed: sp.get('breed') || '',
    location: sp.get('location') || '', minAge: sp.get('minAge') || '', maxAge: sp.get('maxAge') || '',
    available: sp.get('available') ?? 'true',
  };

  const set = (k, v) => {
    const next = new URLSearchParams(sp);
    if (v === '') next.delete(k); else next.set(k, v);
    setSp(next, { replace: true });
  };

  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => {
      api.pets({ ...f, available: f.available === 'all' ? '' : f.available })
        .then((d) => { setPets(d); setError(''); })
        .catch((e) => setError(e.message))
        .finally(() => setLoading(false));
    }, 250); // debounce typing
    return () => clearTimeout(t);
  }, [sp]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="container section">
      <h1>Browse pets</h1>
      <div className="card filters">
        <input placeholder="Search name or breed…" value={f.q} onChange={(e) => set('q', e.target.value)} />
        <select value={f.species} onChange={(e) => set('species', e.target.value)} aria-label="Species">
          <option value="">All species</option>
          {SPECIES.map((s) => <option key={s}>{s}</option>)}
        </select>
        <input placeholder="Breed" value={f.breed} onChange={(e) => set('breed', e.target.value)} />
        <input placeholder="Location" value={f.location} onChange={(e) => set('location', e.target.value)} />
        <input type="number" min="0" placeholder="Min age" value={f.minAge} onChange={(e) => set('minAge', e.target.value)} />
        <input type="number" min="0" placeholder="Max age" value={f.maxAge} onChange={(e) => set('maxAge', e.target.value)} />
        <select value={f.available} onChange={(e) => set('available', e.target.value)} aria-label="Availability">
          <option value="true">Available</option>
          <option value="all">All</option>
        </select>
        <button className="btn btn-ghost" onClick={() => setSp({}, { replace: true })}>Clear</button>
      </div>

      {error && <div className="alert error">{error}</div>}
      {loading && !pets.length ? <p className="muted">Loading…</p>
        : pets.length === 0 && !error ? <div className="empty"><h3>No pets match your filters</h3><p className="muted">Try clearing a filter.</p></div>
        : <div className="grid pets">{pets.map((p) => <PetCard key={p.id} pet={p} />)}</div>}
    </div>
  );
}
