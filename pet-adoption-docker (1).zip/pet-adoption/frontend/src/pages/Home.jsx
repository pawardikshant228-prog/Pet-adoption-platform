import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import PetCard from '../components/PetCard.jsx';

export default function Home() {
  const [pets, setPets] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api.pets({ available: true }).then((p) => setPets(p.slice(0, 3))).catch((e) => setError(e.message));
  }, []);

  return (
    <>
      <section className="hero">
        <div className="container hero-inner">
          <div>
            <p className="eyebrow">Online pet adoption platform</p>
            <h1>Find the pet who's been waiting for you.</h1>
            <p className="lead">Browse verified profiles in one place, compare with simple filters, and send an adoption request in minutes.</p>
            <div className="row">
              <Link to="/pets" className="btn btn-primary btn-lg">Browse pets</Link>
              <Link to="/register" className="btn btn-outline btn-lg">Create account</Link>
            </div>
          </div>
          <div className="hero-art" aria-hidden="true">🐶 🐱 🐰</div>
        </div>
      </section>

      <section className="container section">
        <h2>How it works</h2>
        <div className="grid steps">
          {[['01', 'Browse', 'Explore pets from one searchable list.'],
            ['02', 'Compare', 'Filter by species, breed, age and location.'],
            ['03', 'Understand', 'Read health notes, care details and availability.'],
            ['04', 'Apply', 'Submit a request and track its status.']].map(([n, t, d]) => (
            <div className="card step" key={n}><span className="step-n">{n}</span><h3>{t}</h3><p className="muted">{d}</p></div>
          ))}
        </div>
      </section>

      <section className="container section">
        <div className="row between"><h2>Meet some of our pets</h2><Link to="/pets">See all →</Link></div>
        {error && <div className="alert error">{error}</div>}
        <div className="grid pets">{pets.map((p) => <PetCard key={p.id} pet={p} />)}</div>
      </section>
    </>
  );
}
