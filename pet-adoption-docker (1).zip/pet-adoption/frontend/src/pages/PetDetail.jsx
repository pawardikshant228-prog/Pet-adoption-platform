import { useEffect, useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { FALLBACK, ageLabel } from '../components/PetCard.jsx';

export default function PetDetail() {
  const { id } = useParams();
  const { user, isAdmin } = useAuth();
  const nav = useNavigate();
  const [pet, setPet] = useState(null);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [fieldErr, setFieldErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    api.pet(id).then(setPet).catch((e) => setError(e.message));
  }, [id]);

  const submit = async (e) => {
    e.preventDefault();
    setError(''); setFieldErr('');
    if (message.trim().length < 10) { setFieldErr('Tell us a little more (at least 10 characters).'); return; }
    setBusy(true);
    try {
      await api.submitRequest({ petId: pet.id, message });
      setDone(true);
    } catch (err) {
      if (err.fields?.message) setFieldErr(err.fields.message); else setError(err.message);
    } finally { setBusy(false); }
  };

  if (error && !pet) return <div className="container section"><div className="alert error">{error}</div><Link to="/pets">← Back to pets</Link></div>;
  if (!pet) return <div className="container section muted">Loading…</div>;

  return (
    <div className="container section">
      <Link to="/pets">← Back to pets</Link>
      <div className="detail">
        <img className="detail-img" src={pet.imageUrl || FALLBACK} alt={pet.name} onError={(e) => { e.currentTarget.src = FALLBACK; }} />
        <div>
          <div className="row between">
            <h1>{pet.name}</h1>
            <span className={pet.available ? 'badge ok' : 'badge off'}>{pet.available ? 'Available' : 'Adopted'}</span>
          </div>
          <dl className="facts">
            <div><dt>Species</dt><dd>{pet.species}</dd></div>
            <div><dt>Breed</dt><dd>{pet.breed || '—'}</dd></div>
            <div><dt>Age</dt><dd>{ageLabel(pet.ageYears)}</dd></div>
            <div><dt>Gender</dt><dd>{pet.gender || '—'}</dd></div>
            <div><dt>Location</dt><dd>{pet.location}</dd></div>
            <div><dt>Health</dt><dd>{pet.healthNotes || '—'}</dd></div>
          </dl>
          <p>{pet.description}</p>

          <div className="card apply">
            <h3>Adopt {pet.name}</h3>
            {done ? (
              <div className="alert success">
                Request sent! The shelter will review it soon.{' '}
                <Link to="/my-requests">Track your requests →</Link>
              </div>
            ) : !pet.available ? (
              <p className="muted">{pet.name} has found a home. <Link to="/pets">See other pets</Link>.</p>
            ) : !user ? (
              <p><Link to="/login" state={{ from: `/pets/${pet.id}` }}>Log in</Link> or <Link to="/register">sign up</Link> to send an adoption request.</p>
            ) : isAdmin ? (
              <p className="muted">Admins can manage this pet from the admin dashboard.</p>
            ) : (
              <form onSubmit={submit} noValidate>
                <label htmlFor="msg">Why would you be a great match?</label>
                <textarea id="msg" rows="4" maxLength="1000" value={message} onChange={(e) => setMessage(e.target.value)}
                          placeholder="Tell us about your home, experience with pets, and daily routine." />
                {fieldErr && <p className="field-error">{fieldErr}</p>}
                {error && <div className="alert error">{error}</div>}
                <button className="btn btn-primary" disabled={busy}>{busy ? 'Sending…' : 'Submit request'}</button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
