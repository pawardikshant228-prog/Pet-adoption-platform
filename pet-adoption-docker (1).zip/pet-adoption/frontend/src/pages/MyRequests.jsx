import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import StatusBadge from '../components/StatusBadge.jsx';

export default function MyRequests() {
  const [rows, setRows] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { api.myRequests().then(setRows).catch((e) => setError(e.message)); }, []);

  return (
    <div className="container section">
      <h1>My adoption requests</h1>
      {error && <div className="alert error">{error}</div>}
      {rows === null && !error ? <p className="muted">Loading…</p>
        : rows?.length === 0 ? <div className="empty"><h3>No requests yet</h3><Link to="/pets" className="btn btn-primary">Browse pets</Link></div>
        : <div className="list">
            {rows?.map((r) => (
              <div className="card req" key={r.id}>
                <Link to={`/pets/${r.petId}`}><strong>{r.petName}</strong></Link>
                <StatusBadge status={r.status} />
                <span className="muted small">{new Date(r.requestDate).toLocaleDateString()}</span>
                <p className="muted">“{r.message}”</p>
                {r.reviewNotes && <p className="small"><strong>Shelter note:</strong> {r.reviewNotes}</p>}
              </div>
            ))}
          </div>}
    </div>
  );
}
