# PawHome – Online Pet Adoption Platform

React + Spring Boot + MySQL, following the architecture in the review deck:
`User → React UI → REST API → Spring Boot (Controller → Service → Repository) → JPA/Hibernate → MySQL`

## Run the backend (Java 17+, Maven)
```
cd backend
# Option A – MySQL: set DB_USERNAME / DB_PASSWORD env vars (defaults root/root); DB is auto-created
mvn spring-boot:run
# Option B – no MySQL needed (in-memory H2)
mvn spring-boot:run -Dspring-boot.run.profiles=h2
```
API on http://localhost:8080. Sample pets and an admin are seeded on first start:
**admin@petadopt.com / Admin@123** (change in application.properties).

## Run the frontend (Node 18+)
```
cd frontend
npm install
npm run dev        # http://localhost:5173
```
API URL is set in `frontend/.env` (`VITE_API_URL`).

## REST API
| Method | Path | Access |
|---|---|---|
| POST | /auth/register, /auth/login | public |
| GET | /pets?q&species&breed&location&minAge&maxAge&available | public |
| GET | /pets/{id} | public |
| POST/PUT/DELETE | /pets, /pets/{id} | admin |
| POST | /adoption-requests `{petId, message}` | logged in |
| GET | /adoption-requests/mine | logged in |
| GET | /admin/adoption-requests, /admin/stats | admin |
| PATCH | /admin/adoption-requests/{id} `{status, reviewNotes}` | admin |

Rules: duplicate pending requests are blocked, unavailable pets can't be requested,
approving a request marks the pet as adopted.

## Postman example
POST /auth/login `{"email":"admin@petadopt.com","password":"Admin@123"}` → copy `token`,
then send `Authorization: Bearer <token>` on protected calls.
